package com.example.android.book_listing_app;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by akash on 15/10/16.
 */

public class Book implements Parcelable {

    private String mTitle;
    private String mAuthor;
    private String mPublisher;


    public Book(String title, String author, String publisher) {
        mTitle = title;
        mAuthor = author;
        mPublisher = publisher;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public String getmPublisher(){return mPublisher;}

    protected Book(Parcel in) {
        mTitle = in.readString();
        mAuthor = in.readString();
        mPublisher = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mTitle);
        dest.writeString(mAuthor);
        dest.writeString(mPublisher);
    }

    @SuppressWarnings("not used")
    public static final Parcelable.Creator<Book> CREATOR = new Parcelable.Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel in) {
            return new Book(in);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };
}
