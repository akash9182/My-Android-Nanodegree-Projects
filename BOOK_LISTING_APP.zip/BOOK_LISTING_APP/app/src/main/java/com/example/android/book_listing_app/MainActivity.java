package com.example.android.book_listing_app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private BookAdapter mBookAdapter;
    public static final String LOG_TAG = MainActivity.class.getSimpleName();
    private static final String BOOK_REQUEST_URL = "https://www.googleapis.com/books/v1/volumes?q=";
    ArrayList<Book> bookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v(LOG_TAG, "Test: in oncreate()");
        setContentView(R.layout.activity_main);
        if(savedInstanceState == null || !savedInstanceState.containsKey("bookList")) {
            bookList = new ArrayList<>();
        }
        else {
            bookList = savedInstanceState.getParcelableArrayList("bookList");
        }

        final EditText inputString = (EditText) findViewById(R.id.edit_text_view);

        Button searchButton = (Button) findViewById(R.id.searchButton);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String search = inputString.getText().toString().replace(" ", "+");
                String url = (BOOK_REQUEST_URL + search);
                if (Found(getApplicationContext())) {
                    BookAsyncTask task = new BookAsyncTask();
                    task.execute(url);
                } else {
                    Toast.makeText(getApplicationContext(), "Check your internet connection!", Toast.LENGTH_LONG).show();
                }
            }
        });

        ListView bookListView = (ListView) findViewById(R.id.list);
        bookListView.setEmptyView(findViewById(R.id.empty_list_view));
        mBookAdapter = new BookAdapter(this, bookList);
        bookListView.setAdapter(mBookAdapter);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        Log.v(LOG_TAG, "Test: in onSaveInstanceState()");
        outState.putParcelableArrayList("bookList", bookList);
        super.onSaveInstanceState(outState);
    }

    public boolean Found(Context context) {
        ConnectivityManager connection =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = connection.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }

    private class BookAsyncTask extends AsyncTask<String, Void, ArrayList<Book>> {

        @Override
        protected ArrayList<Book> doInBackground(String... urls) {

            URL url = createUrl(urls[0]);

            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                Log.e(LOG_TAG, "Problem making the HTTP request.", e);
            }
            ArrayList<Book> books = jsonContent(jsonResponse);
            return books;
        }

        @Override
        protected void onPostExecute(ArrayList<Book> books) {
            mBookAdapter.clear();

            if (books != null) {
                mBookAdapter.addAll(books);
            }
        }

        private URL createUrl(String stringUrl) {
            URL url;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }

        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";

            if (url == null) {
                return jsonResponse;
            }

            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.connect();

                if (urlConnection.getResponseCode() == 200) {
                    inputStream = urlConnection.getInputStream();
                    jsonResponse = readFromStream(inputStream);
                } else {
                    Log.e(LOG_TAG, "Error response code: " + urlConnection.getResponseCode());
                }
            } catch (IOException e) {
                Log.e(LOG_TAG, "Problem retrieving the book from JSON results.", e);
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }

        private ArrayList<Book> jsonContent(String bookJSON) {

            if (TextUtils.isEmpty(bookJSON)) {
                return null;
            }

            bookList = new ArrayList<>();

            try {
                JSONObject baseJsonResponse = new JSONObject(bookJSON);
                JSONArray itemsArray = baseJsonResponse.getJSONArray("items");
                if (itemsArray.length() > 0) {
                    for (int i = 0; i < itemsArray.length(); i++) {
                        JSONObject itemsArrayJSONObject = itemsArray.getJSONObject(i);
                        JSONObject volumeInfo = itemsArrayJSONObject.getJSONObject("volumeInfo");
                        String title = volumeInfo.getString("title");
                        StringBuilder authors = new StringBuilder();
                        String publisher = volumeInfo.getString("publisher");
                        if (volumeInfo.has("authors")) {
                            JSONArray authorsArray = volumeInfo.getJSONArray("authors");

                            for (int j = 0; j < authorsArray.length(); j++) {
                                if(j > 0){
                                    authors.append(", ");
                                }
                                authors.append(authorsArray.getString(j));
                            }
                            Book book = new Book(title, authors.toString(), publisher);
                            bookList.add(book);
                        }
                    }
                }

            } catch (JSONException e) {
                Log.e(LOG_TAG, "Problem parsing the book JSON results", e);
            }
            return bookList;
        }
    }
}
