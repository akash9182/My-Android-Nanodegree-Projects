package com.example.android.habittracker.Data;

import android.provider.BaseColumns;

/**
 * Created by akash on 18/10/16.
 */

public class HabitContract {

    public static class HabitEntry implements BaseColumns {
        public final static String TABLE_NAME = "my_habits";
        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_WAKE_UP_TIME = "wake";
        public final static String COLUMN_SLEEP_TIME = "sleep";
        public final static String COLUMN_ATE_BREAKFAST = "breakfast";
        public final static String COLUMN_ATE_LUNCH = "lunch";
        public final static String COLUMN_ATE_DINNER = "dinner";
    }

}
