package com.example.android.habittracker.Data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by akash on 18/10/16.
 */

public class HabitDbHelper extends SQLiteOpenHelper {

    public static final String databaseName = "my_habits.db";
    public static final int databaseVersion = 1;
    public static String something = "null";

    public HabitDbHelper(Context context) {
        super(context, databaseName, null, databaseVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.i("onCreate", "called");
        String SQL_CREATE_HABIT_TABLE = "CREATE TABLE " + HabitContract.HabitEntry.TABLE_NAME + " ("
                + HabitContract.HabitEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + HabitContract.HabitEntry.COLUMN_WAKE_UP_TIME + " INTEGER, "
                + HabitContract.HabitEntry.COLUMN_SLEEP_TIME + " INTEGER, "
                + HabitContract.HabitEntry.COLUMN_ATE_BREAKFAST + " TEXT, "
                + HabitContract.HabitEntry.COLUMN_ATE_LUNCH + " TEXT, "
                + HabitContract.HabitEntry.COLUMN_ATE_DINNER + " TEXT);";
        something = SQL_CREATE_HABIT_TABLE;
        Log.i("onCreate:", SQL_CREATE_HABIT_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + HabitContract.HabitEntry.TABLE_NAME);
        sqLiteDatabase.execSQL(SQL_CREATE_HABIT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int j) {

    }
}