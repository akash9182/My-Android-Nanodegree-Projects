package com.example.android.habittracker;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.example.android.habittracker.Data.HabitContract;
import com.example.android.habittracker.Data.HabitContract.HabitEntry;
import com.example.android.habittracker.Data.HabitDbHelper;
public class MainActivity extends AppCompatActivity {

    private HabitDbHelper mHabitDbHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // main code
        mHabitDbHelper = new HabitDbHelper(this);
        db = mHabitDbHelper.getWritableDatabase();

        try {
            Thread.sleep(5000);
        } catch(InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        insertHabit();
        displayDatabaseInfo();
    }

    private void insertHabit() {
        ContentValues values = new ContentValues();
        values.put(HabitContract.HabitEntry.COLUMN_WAKE_UP_TIME, 7);
        values.put(HabitContract.HabitEntry.COLUMN_SLEEP_TIME, 23);
        values.put(HabitContract.HabitEntry.COLUMN_ATE_BREAKFAST, "Milk");
        values.put(HabitContract.HabitEntry.COLUMN_ATE_LUNCH, "Rice");
        values.put(HabitContract.HabitEntry.COLUMN_ATE_DINNER, "Biryani");

        db.insert(HabitContract.HabitEntry.TABLE_NAME, null, values);
        Log.i("insertHabit", "complete");
    }

    public void displayDatabaseInfo() {

        SQLiteDatabase db = mHabitDbHelper.getReadableDatabase();

        String[] projection = {
                HabitContract.HabitEntry._ID,
                HabitContract.HabitEntry.COLUMN_WAKE_UP_TIME,
                HabitContract.HabitEntry.COLUMN_SLEEP_TIME,
                HabitContract.HabitEntry.COLUMN_ATE_BREAKFAST,
                HabitContract.HabitEntry.COLUMN_ATE_LUNCH,
                HabitContract.HabitEntry.COLUMN_ATE_DINNER
        };
        Cursor cursor = db.query(true,
                HabitContract.HabitEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null,
                null);

        TextView textDisplay = (TextView) findViewById(R.id.display_textview);

        try {
            textDisplay.setText("No. of actions saved " + cursor.getCount() + "\n\n");
            textDisplay.append(
                    HabitContract.HabitEntry._ID + " - " +
                            HabitContract.HabitEntry.COLUMN_WAKE_UP_TIME + " - " +
                            HabitContract.HabitEntry.COLUMN_SLEEP_TIME + " - " +
                            HabitContract.HabitEntry.COLUMN_ATE_BREAKFAST + " - " +
                            HabitContract.HabitEntry.COLUMN_ATE_LUNCH + " - " +
                            HabitContract.HabitEntry.COLUMN_ATE_DINNER + "\n"
            );

            int idColumnIndex = cursor.getColumnIndex(HabitContract.HabitEntry._ID);
            int wakeColumnIndex = cursor.getColumnIndex(HabitContract.HabitEntry.COLUMN_WAKE_UP_TIME);
            int sleepColumnIndex = cursor.getColumnIndex(HabitContract.HabitEntry.COLUMN_SLEEP_TIME);
            int breakfastColumnIndex = cursor.getColumnIndex(HabitContract.HabitEntry.COLUMN_ATE_BREAKFAST);
            int lunchColumnIndex = cursor.getColumnIndex(HabitContract.HabitEntry.COLUMN_ATE_LUNCH);
            int dinnerColumnIndex = cursor.getColumnIndex(HabitContract.HabitEntry.COLUMN_ATE_DINNER);

            while (cursor.moveToNext()) {

                int id = cursor.getInt(idColumnIndex);
                long wakeTime = cursor.getLong(wakeColumnIndex);
                long sleepTime = cursor.getLong(sleepColumnIndex);
                String breakfast = cursor.getString(breakfastColumnIndex);
                String lunch = cursor.getString(lunchColumnIndex);
                String dinner = cursor.getString(dinnerColumnIndex);


                textDisplay.append(("\n" +
                        id + " - " +
                        wakeTime + " - " +
                        sleepTime + " - " +
                        breakfast + " - " +
                        lunch + " - " +
                        dinner));
            }
        } finally {

            cursor.close();

        }

    }
}