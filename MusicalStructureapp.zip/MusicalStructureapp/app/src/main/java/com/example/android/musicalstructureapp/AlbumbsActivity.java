package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AlbumbsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_albumbs);

        final Button nowPlaying = (Button) findViewById(R.id.now_playing);

        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent nowPlayingActivity = new Intent(AlbumbsActivity.this, NowplayingActivity.class);

                AlbumbsActivity.this.startActivity(nowPlayingActivity);
            }
        });
    }
}
