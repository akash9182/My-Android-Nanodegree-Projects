package com.example.android.musicalstructureapp;

import android.app.Activity;
import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static android.os.Build.VERSION_CODES.N;

public class ArtistsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artists);

        final Button songlist = (Button) findViewById(R.id.songlist);

        // This gives the search button a click function
        songlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent songlistActivity = new Intent(ArtistsActivity.this, SonglistActivity.class);

                ArtistsActivity.this.startActivity(songlistActivity);
            }
        });
    }
}
