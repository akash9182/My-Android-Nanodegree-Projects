package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button albums = (Button) findViewById(R.id.albums);

        // This gives the Now Playing button a click function
        albums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent albumActivity = new Intent(MainActivity.this, AlbumbsActivity.class);

                MainActivity.this.startActivity(albumActivity);
            }
        });

        // Set the musicLibraryButton to the music_library_button
        final Button artist = (Button) findViewById(R.id.artists);

        // This gives the Music Library button a click function
        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent artistActivity = new Intent(MainActivity.this, ArtistsActivity.class);

                MainActivity.this.startActivity(artistActivity);
            }
        });

        // Set the musicStoreButton to the music_store_button
        final Button genere = (Button) findViewById(R.id.generes);

        // This gives the Music Store button a click function
        genere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent genereStoreActivity = new Intent(MainActivity.this, GeneresActivity.class);

                MainActivity.this.startActivity(genereStoreActivity);
            }
        });


        // Set the searchButton to the search_button
        final Button library = (Button) findViewById(R.id.library);

        // This gives the search button a click function
        library.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent libraryActivity = new Intent(MainActivity.this, LibraryActivity.class);

                MainActivity.this.startActivity(libraryActivity);
            }
        });

        // Set the searchButton to the search_button
        final Button nowPlaying = (Button) findViewById(R.id.now_playing);

        // This gives the search button a click function
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent nowPlayingActivity = new Intent(MainActivity.this, NowplayingActivity.class);

                MainActivity.this.startActivity(nowPlayingActivity);
            }
        });
    }
}
