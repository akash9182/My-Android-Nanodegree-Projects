package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SonglistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songlist);

        final Button nowPlaying = (Button) findViewById(R.id.now_playing);

        // This gives the search button a click function
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // By clicking on the Now Playing button will lead the user to the nowPlaying Activity
                Intent nowPlayingActivity = new Intent(SonglistActivity.this, NowplayingActivity.class);

                SonglistActivity.this.startActivity(nowPlayingActivity);
            }
        });
    }
}
