void main(){
	printf("%s\n aaaaaaaaaaa");
}