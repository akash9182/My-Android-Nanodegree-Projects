package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import static android.R.attr.name;
import static android.R.id.edit;
import static com.example.android.quizapp.R.id.radioGroup1;

public class MainActivity extends AppCompatActivity {

    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method displays the score in the end by a toast
     *
     * @param view
     */
    public void displayScore(View view) {

        RadioGroup radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup1);
        RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.radioGroup2);
        RadioGroup radioGroup3 = (RadioGroup) findViewById(R.id.radioGroup3);
        RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.radioGroup4);
        RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.radioGroup5);

        EditText answer_6 = (EditText) findViewById(R.id.answer6);
        String user_answer_6 = answer_6.getText().toString();

        checkQuestion6(user_answer_6);

        EditText answer_7 = (EditText) findViewById(R.id.answer7);
        answer_7.setInputType(InputType.TYPE_CLASS_NUMBER);
        String user_answer_7 = answer_7.getText().toString();

        checkQuestion7(user_answer_7);

        CheckBox checkBox_1 = (CheckBox) findViewById(R.id.checkbox_1);
        boolean isFramework1 = checkBox_1.isChecked();

        CheckBox checkBox_2 = (CheckBox) findViewById(R.id.checkbox_2);
        boolean isFramework2 = checkBox_2.isChecked();

        CheckBox checkBox_3 = (CheckBox) findViewById(R.id.checkbox_3);
        boolean isFreamewok3 = checkBox_3.isChecked();

        CheckBox checkBox_4 = (CheckBox) findViewById(R.id.checkbox_4);
        boolean isFramework4 = checkBox_4.isChecked();

        cheeckQuestion8(isFramework1, isFramework2, isFreamewok3, isFramework4);

        if (score == 8) {
            Toast.makeText(this, "Great! You correctly answered all 8 questions!",
                    Toast.LENGTH_LONG).show();
        }else
            Toast.makeText(this, "You correctly answered " + score + " out of 8 questions!",
                    Toast.LENGTH_LONG).show();


        // Resets all Radiobuttons
        radioGroup1.clearCheck();
        radioGroup2.clearCheck();
        radioGroup3.clearCheck();
        radioGroup4.clearCheck();
        radioGroup5.clearCheck();

        // Resets all EditText view
        answer_6.setText("");
        answer_7.setText("");

        // Rests all checkboxes
        checkBox_1.setChecked(false);
        checkBox_2.setChecked(false);
        checkBox_3.setChecked(false);
        checkBox_4.setChecked(false);

        // reset score
        score = 0;
    }

    /**
     * This method is used to check the answer for 1st question by checking if the Radio button is clicked
     * If yes then caluclate the score accordingly
     */
    public void onRadioButtonClicked1(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButton1_1:
                if (checked) // Plus 1 point for correct answer
                    score = score + 1;
        }

    }

    /**
     * This method is used to check the answer for 2nd question by checking if the Radio button is clicked
     * If yes then caluclate the score accordingly
     */
    public void onRadioButtonClicked2(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButton2_2:
                if (checked) // Plus 1 point for correct answer
                    score = score + 1;
        }

    }

    /**
     * This method is used to check the answer for 3rd question by checking if the Radio button is clicked
     * If yes then caluclate the score accordingly
     */
    public void onRadioButtonClicked3(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButton3_3:
                if (checked) // Plus 1 point for correct answer
                    score = score + 1;
        }

    }

    /**
     * This method is used to check the answer for 4th question by checking if the Radio button is clicked
     * If yes then caluclate the score accordingly
     */
    public void onRadioButtonClicked4(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButton4_4:
                if (checked) // Plus 1 point for correct answer
                    score = score + 1;
        }

    }

    /**
     * This method is used to check the answer for 5th question by checking if the Radio button is clicked
     * If yes then caluclate the score accordingly
     */
    public void onRadioButtonClicked5(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch (view.getId()) {
            case R.id.radioButton5_1:
                if (checked) // Plus 1 point for correct answer
                    score = score + 1;
        }

    }

    // This method is used to check answer for 6th question by String comparison

    public void checkQuestion6(String user_answer) {
        String correct_ans_6 = "Extensible";

        if (user_answer.equals(correct_ans_6)) {
            score = score + 1;
        }
    }

    // This method is used to check answer for 7th question by String comparison

    public void checkQuestion7(String user_answer) {
        String correct_ans_7 = "8";

        if (user_answer.equals(correct_ans_7)) {
            score = score + 1;
        }
    }

    // This method is used to check answer for 8th question

    public void cheeckQuestion8(boolean option1, boolean option2, boolean option3, boolean option4) {
        if (option1 & option2 & option4 == true & option3 != true) {
            score = score + 1;
        }
    }

}
