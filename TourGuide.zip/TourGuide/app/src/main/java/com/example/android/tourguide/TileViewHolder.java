package com.example.android.tourguide;

import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by akash on 11/10/16.
 */

public class TileViewHolder {
    ImageView image;
    TextView oneLineDescription;
    TextView description;
    TextView maps;
    TextView nameOfTile;
}
